from CACM.algorithms.abstractDANN import AbstractDANN

class CDANN(AbstractDANN):
    """Conditional DANN"""
    def __init__(self, model, optimizer="Adam", lr=1e-3, weight_decay=0.0, betas=(0.9, 0.999), momentum=0.9, 
                 conditional=False, class_balance=False, d_steps_per_g=1, gradient_penalty=1e-2, DANN_lambda = 1e-1):
        super(CDANN, self).__init__(model, optimizer="Adam", lr=1e-3, weight_decay=0.0, betas=(0.9, 0.999), momentum=0.9, 
                 conditional=True, class_balance=True, d_steps_per_g=1, gradient_penalty=1e-2, DANN_lambda = 1e-1)
